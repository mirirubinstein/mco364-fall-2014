package rubinstein.chat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

import javax.swing.JTextField;

public class ChatClient extends ChatFrame{

	private Socket socket;
	
	public ChatClient(){
		super();
	
		try {
			socket = new Socket("localhost", 8080);
			setSocket(socket);
	
			
			
		} catch ( IOException e) {
			e.printStackTrace();
		}
		}
	

	public static void main(String[] args) {
		ChatFrame c2 = new ChatClient();
		c2.setLocationRelativeTo(null);
		
	}

}
